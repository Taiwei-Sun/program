import java.net.ServerSocket;
import java.net.Socket;
import java.lang.Thread;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.Exception;

public class webServer{
public static void main(String[] args) {
	final int pPort=80;
	try{
	ServerSocket server = new ServerSocket(pPort);
	myServer webb=new myServer(server);
	webb.run();
	} catch (Exception e) { e.printStackTrace(); }
}
}
class myServer extends Thread {
ServerSocket server ;
public myServer(ServerSocket s){
	server=s;
}
 public void run() {
    try {
      Socket socket = server.accept();      // 等待直到接受到瀏覽器的連線訊息，然後建立連線。
      Thread service = new Thread(this);    // 建立一個新的 WebServer 執行緒。
      service.start();                      // 啟動它以以便處理下一個請求。
      OutputStream out = socket.getOutputStream(); // 取得傳送資料的輸出檔。
      InputStream in = socket.getInputStream();     // 取得接收資料的輸入檔。
      String request = request(in);         // 讀取瀏覽器傳來的請求訊息。
      //response(request, out);               // 回應訊息給對方的瀏覽器。
      socket.close();                       // 關閉該連線。
    } catch (Exception e) { e.printStackTrace(); }
  }
String request(InputStream in) {
    String request = "";
    try {
      // 讀取到第一個空白行為止，這是標頭訊息。
      while (true) {
        String line = myReadLine(in);
        if (line == null) break;
        request += line+"\r\n";
        if (line.length() == 0) break;
      }
      System.out.println(request);
    } catch (Exception e) { e.printStackTrace(); }
    return request;
  }
String myReadLine(InputStream in){
	String s="";
	byte[] b=new byte[1];
	try{
	while(in.read(b)!=-1){
		if(b[0]!=0x0a)
		{
			s+=new String(b, "UTF-8");
		}
		else break;
	}	
	} catch (Exception e) { e.printStackTrace(); }
	return s;

}

}
