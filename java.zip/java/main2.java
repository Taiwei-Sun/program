import java.util.Scanner;

public class main{
        public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        int n;
        String a1,a2;
        a1=cin.nextLine();
        a2=cin.nextLine();
        n=a1.length();
        String a3[]=a1.split("");
        String a4[]=a2.split("");

        for(int m=1;m<=n;m=m+1)
        {
        for(int k=1;k<=n;k=k+1)
        {
                if (a3[m].equals(a4[k])==true){
                System.out.print("a4["+k+"]="+a4[k]);
                a3[m]="2";
                a4[k]="2";
                k=n;
                }
        }
        System.out.println("");
        }

        for(int i=1;i<=n;i++){

                if(a3[i].equals(a4[i])==false){System.out.println("0");i=n;}
                else if(i==n){System.out.println("1");}
        }
       }
}

