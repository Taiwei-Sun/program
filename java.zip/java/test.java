import java.util.Scanner;
public class test {
	public static void main(String[] args) {
	String str1="asdfa";
	char chr[]=str1.toCharArray();
	char ch1[]=str1.toCharArray();
	if(chr[0]==ch1[3])System.out.println("1");
	else System.out.println("0");
		
	}
}
