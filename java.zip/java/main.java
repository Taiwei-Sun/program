import java.util.Scanner;
public class main{
	public static void main(String[] args) {
	Scanner cin = new Scanner(System.in);
	int pre,n;
	boolean same=true;
	n=Integer.parseInt(cin.nextLine());
	String str[]=new String[n];
	char ch[][]=new char[n][];
	str[0]=cin.nextLine();
	ch[0]=str[0].toCharArray();
	pre=str[0].length();
	
	for(int i=0;i<n-1;i++){
	
	str[i+1]=cin.nextLine();
	ch[i+1]=str[i+1].toCharArray();

	if(str[i].length()==str[i+1].length()&&equals1(pre,ch[i],ch[i+1]))pre=str[i+1].length();
	else same=false;
		
	
	if(i==n-2&&same)System.out.println("1");
	else if(!same)System.out.println("0");
	
	}

	}
	public static boolean equals1(int n,char ch1[],char ch2[]){
	char tmp1[]=new char[ch1.length];
	char tmp2[]=new char[ch2.length];
	System.arraycopy(ch1,0,tmp1,0,ch1.length);
	System.arraycopy(ch2,0,tmp2,0,ch2.length);
	
	for(int i=0;i<tmp1.length;i++)
	{
		for(int j=0;j<tmp2.length;j++){
		System.out.println("tmp1["+i+"]="+tmp1[i]+" tmp2["+j+"]="+tmp2[j]);
		if(tmp1[i]==tmp2[j]){
			tmp2[j]='0';
			j=n;
		}
		else if(j==(n-1))return false;
				
		}
	
	}
	return true;

}
}
