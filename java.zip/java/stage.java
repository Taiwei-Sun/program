import java.util.Scanner;
class amateur{
Scanner scanner;
float look,sing,talk,acting;
public int player;
	amateur(int t){
	scanner = new Scanner(System.in);
	player=t; 
	System.out.println("plause,write 4 look,sing,talk and acting(score) for no."+player+"(Note:Separated by spaces)");
	look=scanner.nextInt();
	sing=scanner.nextInt();	
	talk=scanner.nextInt();
	acting=scanner.nextInt();
	
	}
	
	int score(){
	float k=0;
	k=((look+sing)*3/10)+((talk+acting)*2/10);
	if(k>(int)k)k++;
	return (int)k;
	}

}

public class stage {
	public static void main(String[] args){
	int n=Integer.parseInt(args[0]);
	amateur player[]=new amateur[n]; 
	for(int i=0;i<n;i++)player[i]=new amateur(i+1);
	for(int i=0;i<n;i++)System.out.println("no."+player[i].player+" score:"+player[i].score());
	}	

}
