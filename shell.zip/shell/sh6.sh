#!/bin/bash
# Program:
#	
# History:
# 2014/05/08	Sun	First release
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

read -p "Plase,input filename:" fn
test -z $fn && echo "you should input a filename" && exit 0
test ! -e $fn && echo "the file '$fn' do not exist" && exit 0
test -f $fn && filetype=" regulare file"
test -d $fn && filetype=" directory"
test -r $fn && perm=" readable"
test -w $fn && perm="$perm writable"
test -x $fn && perm="$perm executable"
echo "your $fn is $filetype type"
echo "your $fn is $perm perm"
