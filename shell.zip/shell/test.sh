#!/bin/bash

    for langfile in /etc/sysconfig/i18n $HOME/.i18n ; do
    	[ -f $langfile ] && echo $langfile
    done    
exit 0
