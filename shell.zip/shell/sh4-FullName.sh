#!/bin/bash
# Program:
#	
# History:
# 2014/05/08	Sun	First release
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

read -p "input your first name:" firstname
read -p "input your last name:" lastname
echo -e "\nyour full name is $firstname $lastname"

exit 0
