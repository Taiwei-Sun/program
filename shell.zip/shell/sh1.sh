#!/bin/bash
# Program:
#
# History:
# 2014/05/04	Sun	First release
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

read -p "Please input your some word ,i will print this until input \"yes\": " n
until [ "$n" == "yes" ] || [ "$n" == "YES" ]
do

echo "you print : $n"
read -p "Please input your some word ,i will print this until input \"yes\": " n
done
