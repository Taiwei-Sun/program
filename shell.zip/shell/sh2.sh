#!/bin/bash
# Program:
#	1+2+3...+n
# History:
# 2014/05/04	Sun	First release
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

read -p "Please input your some number : " n
declare -i i
while [ "$i" != "$n" ] 
do
i=$(($i+1))
s=$(($s+$i))
done

case $n in
"1")
echo "$n = $s"
;;
"2")
echo "1+ $n = $s"
;;
"3")
echo "1+2+ $n = $s"
;;
*)
echo "1+2+3...+ $n = $s"
;;
esac
