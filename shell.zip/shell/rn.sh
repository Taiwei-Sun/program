#!/bin/bash
# Program:
#	rename
# History:
# 2014/05/08	Sun	First release
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

cp $1 $2
rm -f $1
exit 0
